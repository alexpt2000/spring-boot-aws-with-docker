package com.hibicode.beerstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeerstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeerstoreApplication.class, args);
	}

}
